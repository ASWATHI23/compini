from django.urls import path
from .views import LogView,RegView

urlpatterns = [
    path('login/',LogView.as_view(),name="log"),
    path('register/',RegView.as_view(),name="register")
]
