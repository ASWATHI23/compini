from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import View

# Create your views here.
#def log(request):
    #if request.method=="GET":
     #   return render(request,"log.html")
    #elif request.method=="POST":
     #    print(request.POST.get("uname"))
      #   print(request.POST.get("psw"))
       #  return HttpResponse("post request reached")
class LogView(View):
    def get(self,request,*awrgs,**kwrgs):
         return render(request,"log.html")
    def post(self,request,*awrgs,**kwrgs):
         print(request.POST.get("uname"))
         print(request.POST.get("psw"))
         return HttpResponse("username:"+request.POST.get("uname")+"<br>password:"+request.POST.get("psw"))


class RegView(View):
    def get(self,request,*awrgs,**kwrgs):
       return render(request,"registration.html")
    def post(self,request,*awrgs,**kwrgs):
        print(request.POST.get("fname"))
        print(request.POST.get("lname"))
        print(request.POST.get("email"))
        print(request.POST.get("uname"))
        print(request.POST.get("password"))
        return HttpResponse("registerd")
class MainHome(View):
    def get(self,request,*awrgs,**kwrgs):
        return render(request,"main_home.html")

         
