from django import forms


class AddForm(forms.Form):
    num1=forms.IntegerField()
    num2=forms.IntegerField()

class SubForm(forms.Form):
    num1=forms.IntegerField()
    num2=forms.IntegerField()

class MulForm(forms.Form):
    n1=forms.IntegerField()
    n2=forms.IntegerField()

class DiviForm(forms.Form):
    n1=forms.IntegerField()
    n2=forms.IntegerField()