from django.shortcuts import render
from django.views.generic import View
from .forms import AddForm,SubForm,MulForm,DiviForm

# Create your views here.

class AddView(View):
    def get(self,request,*awrgs,**kwrgs):
        f=AddForm()
        return render(request,"add.html",{"form":f})
    def post(self,request,*awrgs,**kwrgs):
        num1=request.POST.get("num1")
        num2=request.POST.get("num2")
        res=int(num1)+int(num2)
        return render(request,"add.html",{"data":res})
    
class SubView(View):
    def get(self,request,*awrgs,**kwrgs):
        f=SubForm()
        return render(request,"subs.html",{"form":f})
    def post(self,request,*awrgs,**kwrgs):
        num1=request.POST.get("num1")
        num2=request.POST.get("num2")
        res=int(num1)-int(num2)
        return render(request,"subs.html",{"abc":res})

class MulView(View):
    def get(self,request,*awrgs,**kwrgs):
        f=MulForm()
        return render(request,"mul.html",{"form":f})
    def post(self,request,*awrgs,**kwrgs):
        num1=request.POST.get("n1")
        num2=request.POST.get("n2")
        res=int(num1)*int(num2)
        return render(request,"mul.html",{"ef":res})

class DiviView(View):
    def get(self,request,*awrgs,**kwrgs):
        f=DiviForm()
        return render(request,"divi.html",{"form":f})
    def post(self,request,*awrgs,**kwrgs):
        num1=request.POST.get("n1")
        num2=request.POST.get("n2")
        res=int(num1)/int(num2)
        return render(request,"divi.html",{"gh":res})

class CountView(View):
    def get(self,request,*awrgs,**kwrgs):
        return render(request,"wcount.html")
    def post(self,request,*awrgs,**kwrgs):
        sent=request.POST.get("string")
        words=sent.split(" ")
        cnt={}
        for i in words:
            if i in cnt:
                cnt[i]+=1
            else:
                cnt[i]=1
        return render(request,"wcount.html",{"hi":cnt})

