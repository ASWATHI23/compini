from django.urls import path
from .views import *

urlpatterns = [
    path('op/',AddView.as_view(),name="add"),
    path('oper/',SubView.as_view(),name="sub"),
    path('opera/',MulView.as_view(),name="mul"),
    path('operat/',DiviView.as_view(),name="div"),
    path('co/',CountView.as_view(),name="wcnt")
]
