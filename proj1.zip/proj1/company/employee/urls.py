from django.urls import path
from .views import index,HomeView

urlpatterns = [
    path('index/',index),
    path('home/',HomeView.as_view(),name="home")
]