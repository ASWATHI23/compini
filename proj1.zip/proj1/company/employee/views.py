from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import View

# Create your views here.
def index(request):
    return HttpResponse("<h1>Hallo all,Welcome to Django</h1>")
#def home(request):
   # name="mephy"
   # lst=["achu","vismaya","dil"]
   # exp=0
   # return render(request,"home.html",{"a":name,"list":lst,"abc":exp})
class HomeView(View):
    def get(self,request,*args,**kwargs):
         name="mephy"
         lst=["achu","vismaya","dil"]
         exp=0
         return render(request,"home.html",{"a":name,"list":lst,"abc":exp})

